'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAuth } from './auth-provider';
import { RouteAnnouncer } from './route-announcer';

type FontSize = 'sm' | 'md' | 'lg' | 'xl';

interface AccessibilitySettings {
  fontSize: FontSize;
  highContrast: boolean;
  dyslexicFont: boolean;
  reducedMotion: boolean;
  bionicReading: boolean;
  focusMode: boolean;
}

interface AccessibilityContextType extends AccessibilitySettings {
  updateSettings: (newSettings: Partial<AccessibilitySettings>) => void;
  resetSettings: () => void;
}

const defaultSettings: AccessibilitySettings = {
  fontSize: 'md',
  highContrast: false,
  dyslexicFont: false,
  reducedMotion: false,
  bionicReading: false,
  focusMode: false,
};

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

/**
 * Barrier-free accessibility provider for EngelsizForum.
 * Syncs with Supabase profiles if user is logged in.
 */
export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [settings, setSettings] = useState<AccessibilitySettings>(defaultSettings);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [isSyncingFromCloud, setIsSyncingFromCloud] = useState(false);
  const lastSyncedSettings = React.useRef<string>(JSON.stringify(defaultSettings));

  // Initial load from local storage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('accessibility_prefs');
      if (saved) {
        setSettings(JSON.parse(saved));
      }
    } catch (e) {
      console.error('Failed to access or parse accessibility prefs', e);
    }
    setIsInitialLoad(false);
  }, []);

  // Fetch from Supabase when user logs in
  useEffect(() => {
    if (user && isSupabaseConfigured) {
      const fetchPrefs = async () => {
        setIsSyncingFromCloud(true);
        try {
          const { data, error } = await supabase
            .from('profiles')
            .select('accessibility_prefs')
            .eq('id', user.id)
            .maybeSingle();

          if (error) {
            console.warn('Could not fetch prefs from Supabase:', error.message);
          } else if (data?.accessibility_prefs) {
            const cloudSettings = data.accessibility_prefs as AccessibilitySettings;
            setSettings(cloudSettings);
            lastSyncedSettings.current = JSON.stringify(cloudSettings);
          }
        } catch (err) {
          console.error('Exception while fetching prefs:', err);
        } finally {
          setIsSyncingFromCloud(false);
        }
      };
      fetchPrefs();
    }
  }, [user]);

  // Apply and Persist locally
  useEffect(() => {
    if (isInitialLoad) return;

    try {
      const root = document.documentElement;
      root.setAttribute('data-font-size', settings.fontSize);
      root.classList.toggle('high-contrast', settings.highContrast);
      root.classList.toggle('dyslexic-font', settings.dyslexicFont);
      root.classList.toggle('reduced-motion', settings.reducedMotion);
      root.classList.toggle('bionic-reading', settings.bionicReading);
      root.classList.toggle('focus-mode', settings.focusMode);

      localStorage.setItem('accessibility_prefs', JSON.stringify(settings));
    } catch (e) {
      console.warn('Could not persist accessibility settings to local storage', e);
    }

    // Sync with Supabase if logged in and settings actually changed
    const currentSettingsStr = JSON.stringify(settings);
    if (user && isSupabaseConfigured && !isSyncingFromCloud && currentSettingsStr !== lastSyncedSettings.current) {
       supabase
        .from('profiles')
        .update({ 
          accessibility_prefs: settings,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id)
        .then(({ error }) => {
          if (error) {
            console.error('Failed to sync prefs to Supabase:', error.message || 'Unknown error');
            // We'll try again next time they actually change something
            lastSyncedSettings.current = currentSettingsStr;
          } else {
            lastSyncedSettings.current = currentSettingsStr;
          }
        });
    }
  }, [settings, user, isInitialLoad, isSyncingFromCloud]);

  const updateSettings = (newSettings: Partial<AccessibilitySettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const resetSettings = () => setSettings(defaultSettings);

  const accessibilityClasses = !isInitialLoad && settings.highContrast ? 'dark contrast-more' : '';

  return (
    <AccessibilityContext.Provider value={{ ...settings, updateSettings, resetSettings }}>
      <div className={`accessibility-wrapper min-h-screen ${accessibilityClasses}`}>
        <RouteAnnouncer />
        {children}
      </div>
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (!context) throw new Error('useAccessibility must be used within AccessibilityProvider');
  return context;
}
